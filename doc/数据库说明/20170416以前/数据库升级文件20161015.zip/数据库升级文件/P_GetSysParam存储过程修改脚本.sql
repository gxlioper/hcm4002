ALTER procedure [dbo].[P_GetSysParam](  --������ȡ�洢����
   @ParamId varchar(20)='exam_no', /*sys_param���е�param_id��ֵ(exam_no:���ţ�barcode������ţ�vipno��������; lis_order_no:lis��117);
                            pacs:117PACS���; studyid: 117ҽԺpacs��studyid; code:�ֵ������; arch_num_rz��ʡ����Ա��ְ��쵵����
                            contract:��ͬ��ţ�rcpt_num:�շ����뵥��(����HIS�ӿڷ���ɷ�����)*/
   @ParamValue varchar(20) out     --�������ֵ
) 
as
  --set nocount on
  declare @curday varchar(8),
          @curValue varchar(20),
          @tmpValue int,
          @tmpStr varchar(10),
          @head varchar(2)='TM',
          @date datetime

  set @curday=CONVERT(varchar(10), getdate(), 12)
  --select @curday
  if @ParamId='rcpt_num'  --�ɷ����뵥��
  begin
      --set @curday=CONVERT(varchar(10), getdate(), 112)  --yyyymmdd
      set @curday=CONVERT(varchar(10), getdate(), 12)
	  set @curValue=@curday + '000001'
	  if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
		insert into sys_param1(param_id, param_name, param_value, note)
		values('rcpt_num', '�ɷ����뵥��', @curValue, '���ڸ��˽ɷ�����')
	  end
	  else begin
		set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
		if (@curValue=NULL) or (substring(@curValue,1,6)!=@curday)
		  set @curValue=@curday + '000001'
		else begin
		  set @tmpValue=CONVERT(integer, SUBSTRING(@curValue, 7, 6)) + 1
		  set @tmpStr=right('000000'+ cast(@tmpValue as varchar(10)), 6)
		  --select '@tmpStr', @tmpStr
		  set @curValue=@curday + @tmpStr
		end
	  end
  end 
  else if @ParamId='exam_no' 
  begin
      --set @curday=CONVERT(varchar(10), getdate(), 112)  --yyyymmdd
      set @curday=CONVERT(varchar(10), getdate(), 12)
	  set @curValue=@curday + '0001'
	  if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
		insert into sys_param1(param_id, param_name, param_value, note)
		values('exam_no', '����', @curValue, '����')
	  end
	  else begin
		set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
		if (@curValue=NULL) or (substring(@curValue,1,6)!=@curday)
		  set @curValue=@curday + '0001'
		else begin
		  set @tmpValue=CONVERT(integer, SUBSTRING(@curValue, 7, 4)) + 1
		  set @tmpStr=right('0000'+ cast(@tmpValue as varchar(10)), 4)
		  --select '@tmpStr', @tmpStr
		  set @curValue=@curday + @tmpStr
		end
	  end
  end
  else if @ParamId='barcode'   
  begin
     set @curday=CONVERT(varchar(10), getdate(), 112)
     set @date=CONVERT(datetime, @curday)
     set @curday='8'+CAST(convert(int, @date) as varchar(5))
     if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue=@curday+'0001'
		insert into sys_param1(param_id, param_name, param_value, note)
		values('barcode', '��������', @curValue, 'LIS�����')
	  end
	  else begin
		set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
		if (@curValue=NULL) or (substring(@curValue,1,6)!=@curday)
		  set @curValue=@curday+'0001' 
		else begin
		  set @tmpValue=CONVERT(integer, SUBSTRING(@curValue, 7, 4)) + 1
		  set @tmpStr=right('0000'+ cast(@tmpValue as varchar(10)), 4)
		  --select '@tmpStr', @tmpStr
		  set @curValue=@curday+@tmpStr
		end
	  end
  end
  else if @ParamId='vipno'
  begin
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue='TJ0000001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('vipno', '������', @curValue, '��쵵����')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
	    if (@curValue=NULL) or (substring(@curValue,1,2)!='TJ')
	      set @curValue='TJ0000001'
	    else begin
	      set @tmpValue=CONVERT(integer, substring(@curValue,3,7)) + 1
	      set @curValue='TJ'+right('0000000'+ cast(@tmpValue as varchar(7)), 7)
	    end
	  end
  end
  else if @ParamId='contract' --��ͬ���
  begin
    set @curday=CONVERT(varchar(10), getdate(), 12)
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue=@curday+'_0001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('contract', '��ͬ���', @curValue, '��ͬ���')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
		if (@curValue=NULL) or (substring(@curValue,1,6)!=@curday)
		  set @curValue=@curday + '_0001'
		else begin
		  set @tmpValue=CONVERT(integer, SUBSTRING(@curValue, 8, 4)) + 1
		  set @tmpStr=right('0000'+ cast(@tmpValue as varchar(11)), 4)
		  set @curValue=@curday + '_' + @tmpStr
		end
	  end
  end
  else if @ParamId='arch_num_rz'
  begin
    --select substring(CONVERT(varchar(10), getdate(), 120),3,2)
    set @curday=substring(CONVERT(varchar(10), getdate(), 120),3,2)
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue='0'+@curday+'00001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('arch_num_rz', '�����ţ���ְ��', @curValue, 'ʡ����Ա��ְ���')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
	    if (@curValue=NULL) or (substring(@curValue,2,2)!=@curday)
	      set @curValue='0'+@curday+'00001'
	    else begin
	      set @tmpValue=CONVERT(integer, substring(@curValue,4,5)) + 1
	      set @curValue='0'+@curday+right('00000'+ cast(@tmpValue as varchar(5)), 5)
	    end
	  end
  end
  else if @ParamId='lis_order_no'
  begin
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue='T000000001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('lis_order_no', '117 LIS', @curValue, 'LIS��order_no')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
	    if (@curValue=NULL) or (substring(@curValue,1,1)!='T')
	      set @curValue='T000000001'
	    else begin
	      set @tmpValue=CONVERT(integer, substring(@curValue,2,9)) + 1
	      set @curValue='T'+right('000000000'+ cast(@tmpValue as varchar(9)), 9)
	    end
	  end
  end
  else if @ParamId='pacs'
  begin
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue='00000001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('pacs', '117 PACS�������', @curValue, '117 PACS�ӿ��������')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
	    if (@curValue=NULL)
	      set @curValue='00000001'
	    else begin
	      set @tmpValue=CONVERT(integer, @curValue) + 1
	      set @curValue=right('00000000'+ cast(@tmpValue as varchar(8)), 8)
	    end
	  end
  end
  else if @ParamId='studyid'
  begin
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue='000000001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('studyid', 'PACS��studyid', @curValue, '117ҽԺPACS��studyid')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
	    if (@curValue=NULL)
	      set @curValue='000000001'
	    else begin
	      set @tmpValue=CONVERT(integer, @curValue) + 1
	      set @curValue=right('000000000'+ cast(@tmpValue as varchar(9)), 9)
	    end
	  end
  end
  else if @ParamId='code'
  begin
    if not exists (select param_id from sys_param1 where param_id=@ParamId)
	  begin
	    set @curValue='000001'
	    insert into sys_param1(param_id, param_name, param_value, note)
        values('code', '�ֵ������', @curValue, '�ֵ������')
	  end
	  else begin
	    set @curValue=(select param_value from sys_param1 where param_id=@ParamId)
	    if (@curValue=NULL)
	      set @curValue='000001'
	    else begin
	      set @tmpValue=CONVERT(integer, @curValue) + 1
	      set @curValue=right('000000'+ cast(@tmpValue as varchar(6)), 6)
	    end
	  end
  end
  
  update sys_param1 set param_value=@curValue where param_id=@ParamId
  set @ParamValue=@curValue
  --set nocount on

  /*
    declare @ParamValue varchar(20)
  exec P_GetSysParam 'rcpt_num', @ParamValue out
  select @ParamValue
    
    declare @ParamValue varchar(20)
  exec P_GetSysParam 'contract', @ParamValue out
  select @ParamValue
  
  declare @ParamValue varchar(20)
  exec P_GetSysParam 'exam_no', @ParamValue out
  select @ParamValue
  
  declare @ParamValue varchar(20)
  exec P_GetSysParam 'BARCODE', @ParamValue out
  select @ParamValue

  declare @ParamValue varchar(20)
  exec P_GetSysParam 'vipno', @ParamValue out
  select @ParamValue
  
  declare @ParamValue varchar(20)
  exec P_GetSysParam 'arch_num_rz', @ParamValue out
  select @ParamValue
  
  
  declare @ParamValue varchar(20)
  exec P_GetSysParam 'lis_order_no', @ParamValue out
  select @ParamValue
  
  declare @ParamValue varchar(20)
  exec P_GetSysParam 'pacs', @ParamValue out
  select @ParamValue
  
   declare @ParamValue varchar(20)
  exec P_GetSysParam 'studyid', @ParamValue out
  select @ParamValue
  
   declare @ParamValue varchar(20)
  exec P_GetSysParam 'code', @ParamValue out
  select @ParamValue
  */
